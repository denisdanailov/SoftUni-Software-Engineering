package T11_Objects_and_Clsses_LAB;

import java.util.*;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int numberOfSongs = Integer.parseInt(scanner.nextLine());
        List<Songs> songList = new ArrayList<>();
        for (int i = 0; i <numberOfSongs ; i++) {
            String data = scanner.nextLine();
            String typeList = data.split("_")[0];
            String name = data.split("_")[1];
            String time = data.split("_")[2];

            Songs songs = new Songs(typeList,name,time);
            songList.add(songs);

        }
        String typeList = scanner.nextLine();

        if (typeList.equals("all")) {
            for (Songs songs : songList) {
                System.out.println(songs.getName());
            }
        } else {
           List<Songs> filterSongs = songList.stream().filter(e-> e.getTypeList()
                   .equals(typeList))
                   .collect(Collectors.toList());
            for (Songs filterSong : filterSongs) {
                System.out.println(filterSong.getName());
            }
        }
    }
}
