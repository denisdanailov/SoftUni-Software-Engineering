package T12_Objects_and_Classes_Exercise;

public class Person {
//    fields
    private String name;
    private int age;

//    constructor
    public Person(String name, int age) {
        this.name = name;
        this.age = age;

    }
    public String getName() {
        return this.name;
    }

    @Override
    public String toString() {
        return name + " - " + age;
    }
}
