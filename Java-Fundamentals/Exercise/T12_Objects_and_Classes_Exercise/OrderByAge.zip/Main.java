package T12_Objects_and_Classes_Exercise;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String command = scanner.nextLine();
        List<OrderByAge> peoples = new ArrayList<>();
        while (!"End".equals(command)) {
            String name = command.split(" ")[0];
            String id = command.split(" ")[1];
            int age = Integer.parseInt(command.split(" ")[2]);

            OrderByAge orderByAge = new OrderByAge(name,id,age);

            peoples.add(orderByAge);
            command = scanner.nextLine();
        }
        List<OrderByAge> sortedList = peoples.stream()
                .sorted(Comparator.comparing(OrderByAge::getAge))
                .collect(Collectors.toList());
        for (OrderByAge order : sortedList) {
            System.out.println(order);
        }
    }
}
