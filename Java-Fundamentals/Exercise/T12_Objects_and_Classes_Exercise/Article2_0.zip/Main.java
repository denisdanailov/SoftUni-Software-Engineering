package T12_Objects_and_Classes_Exercise;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int n = Integer.parseInt(scanner.nextLine());
        List<Article> listArticles = new ArrayList<>();
        for (int i = 0; i < n ; i++) {
            String input = scanner.nextLine();
            String title = input.split(", ")[0];
            String content = input.split(", ")[1];
            String author = input.split(", ")[2];

          Article article = new Article(title,content,author);

          listArticles.add(article);
        }
        String command = scanner.nextLine();

        switch (command) {
            case "title":
                List<Article> titleSortedList = listArticles.stream()
                        .sorted(Comparator.comparing(Article::getTitle))
                        .collect(Collectors.toList());
                for (Article article : titleSortedList) {
                    System.out.println(article);
                }
                break;
            case "content":
                List<Article> contentSortedList = listArticles.stream()
                        .sorted(Comparator.comparing(Article::getContent))
                        .collect(Collectors.toList());
                for (Article article : contentSortedList) {
                    System.out.println(article);
                }
                break;
            case "author":
                List<Article> authorSortedList = listArticles.stream()
                        .sorted(Comparator.comparing(Article::getAuthor))
                        .collect(Collectors.toList());
                for (Article article : authorSortedList) {
                    System.out.println(article);
                }
                break;
        }
    }
}
